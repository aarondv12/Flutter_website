import 'package:flutter/material.dart';
import 'package:hive/hive.dart';




class DecisionMap{


   int ID;

  late int YesID;

  late int NoID;

  late String Description;

  late String Comments;

  DecisionMap(
   this.ID, this.YesID, this.NoID, this.Description, this.Comments);
}