import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'decision_map.dart';
import 'dart:core';

//Reference to List kept here
List<DecisionMap> decisionMap = [];

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  String csv = "assets/decision_map.csv"; //path to csv file asset
  String fileData = await rootBundle.loadString(csv);
  print(fileData);
  List <String> rows = fileData.split("\n");
  for (int i = 1; i < rows.length; i++)  {
    //selects an item from row and places
    String row = rows[i];
    List <String> itemInRow = row.split(",");
    DecisionMap dm = DecisionMap(
        int.parse(itemInRow[0]),
        int.parse(itemInRow[1]),
        int.parse(itemInRow[2]),
        itemInRow[3],
        itemInRow[4]
    );
    decisionMap.add(dm);
  }

  runApp (
    const MaterialApp(
      home: MyFlutterApp(),
    ),
  );
}

class MyFlutterApp extends StatefulWidget {
  const MyFlutterApp({Key? key}) : super(key: key);
  final String title = "Car search guide";
  @override
  State<StatefulWidget> createState() {
    return MyFlutterState();
  }
}

class MyFlutterState extends State<MyFlutterApp> {
  late int ID;
  late int YesID;
  late int NoID;
  String Description = "";
  String Comments = "";
  String dynamic_text = "";

  @override
  void initState() {
    super.initState();
    dynamic_text = "WELCOME";
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        DecisionMap current = decisionMap.first;
        ID = current.ID;
        YesID = current.YesID;
        NoID = current.NoID;
        Description = current.Description;
        Comments = current.Comments;
      });
    });
  }

  void clickHandler(String button) {
    setState(() {
      for (DecisionMap dm in decisionMap) {
        if (dm.ID == ID) {
          if(button == 'yes'){
            ID = dm.YesID;
          } else {
            ID = dm.NoID;
          }
          for (DecisionMap dm in decisionMap) {
            if (dm.ID == ID) {
              ID = dm.ID;
              YesID = dm.YesID;
              NoID = dm.NoID;
              Description = dm.Description;
              Comments = dm.Comments;
              break;
            }
          }
          break;
        }
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Car Searching Guide"),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(Description, style: Theme.of(context).textTheme.headline5),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(Comments, style: Theme.of(context).textTheme.subtitle1),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                MaterialButton(
                  color: Colors.green,
                  onPressed: () {
                    setState(() {
                      ID = YesID;
                      for (DecisionMap dm in decisionMap) {
                        if (dm.ID == ID) {
                          ID = dm.ID;
                          YesID = dm.YesID;
                          NoID = dm.NoID;
                          Description = dm.Description;
                          Comments = dm.Comments;
                          break;
                        }
                      }
                    });
                  },
                  child: Text("Yes", style: TextStyle(color: Colors.white)),
                ),
                MaterialButton(
                  color: Colors.red,
                  onPressed: () {
                    setState(() {
                      ID = NoID;
                      for (DecisionMap dm in decisionMap) {
                        if (dm.ID == ID) {
                          ID = dm.ID;
                          YesID = dm.YesID;
                          NoID = dm.NoID;
                          Description = dm.Description;
                          Comments = dm.Comments;
                          break;
                        }
                      }
                    });
                  },
                  child: Text("No", style: TextStyle(color: Colors.white)),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

